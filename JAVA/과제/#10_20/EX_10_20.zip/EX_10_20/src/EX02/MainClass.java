package EX02;


public class MainClass {

	public static void main(String[] args) {	
		Word[] words = new Word[100];
		int size =0;
		int j=0;
		String c;
		// TODO Auto-generated method stub
		StringParser sPser = new StringParser("gRape#OraNge#oRANGe#ORange#OranGe#graPE#grapE#OrAnGe#APPLe#BAnANA#aPPLe#gRapE#strAWbErRy#apPlE#StrAWbErRy#apPle#BAnaNA#ORaNgE#BanaNA#StrAWbERRY#BaNaNA#StrAwBErRY#StrAWbeRRY#StrAwBErRY#straWberRy#StrAWBErRy#bAnaNA#OraNGe#aPPLe#gRapE#oRAnGE#grape#BaNAnA#StrAWbErRY#grApe#gRaPE#bAnanA#ORANge#apPle#bAnana#BanaNA#gRapE#StRAWBeRRY#aPPle#BaNaNA#BANANA#strawberRy#gRaPE#apPLe#strAwbErRy#gRApe#gRapE#gRaPE#gRAPe#BaNanA#StrAWBeRRY#APpLe#BaNaNA#BanaNA#ORANgE#oRange#ORanGe#banaNA#ORAnGE#strAwberRy#ORaNge#baNaNA#ORAnge#strawberRy#gRapE#bANaNA#GRapE#ORAnGe#bAnaNA#gRapE#apPLE#BAnaNA#aPPlE#StrAWBErRY#apPle#OrAnGE#grAPe#StrAWBErRY#ORaNge#strAwbErRy#apPLe#APPLe#apPLe#gRape#StrAWBErRY#ORange#gRApE#oRANGE#aPPlE#apPLE#strAwbErRY#appLE#BANAnA#apPlE#apPlE#",'#');
		while (sPser.hasMoreTokens()) {		
			if(size==0){
				words[size] = new Word(sPser.nextToken());
				size++;
			}
			
		
			else
			{
				c=sPser.nextToken();
				for ( j=0 ; j<size ; j++){
					if (words[j].compare(c)){
						break;
					}
				}
				if(j>=size)
				{
					words[size] = new Word(c);
					size++;
				}
				else;
			}		
		}	
		for (int k=0 ; k<size ; k++)
			System.out.println(words[k].s);
	}

}
