package EX01;

public class StringParser {
	
	StringBuffer sb = new StringBuffer();
	char delimeter; //������ #
	
	
	StringParser(String s, char delimeter){				
		sb.append(s);
		this.delimeter=delimeter;
	}
	
	boolean hasMoreTokens() {
		
		if(sb.length()>0)
			return true;
		return false;
		
		
	}
	String nextToken() {
		
		
		String c;
		for (int i=0 ; i<sb.length();i++) {
			if(sb.charAt(i)==this.delimeter) {
				c=sb.substring(0,i);
				sb.delete(0,i+1);
				return c;
			}
		}
		if (sb.length()>0){
			c=sb.toString();
			sb.delete(0,sb.length()+1);
			return c;
		}
		return null;
	}

}
