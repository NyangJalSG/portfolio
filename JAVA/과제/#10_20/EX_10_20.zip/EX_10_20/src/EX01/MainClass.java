package EX01;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringParser sPser = new StringParser("grape#orange#apple",'#');			
		while (sPser.hasMoreTokens()) {
			System.out.println(sPser.nextToken());
			}
	}

}
