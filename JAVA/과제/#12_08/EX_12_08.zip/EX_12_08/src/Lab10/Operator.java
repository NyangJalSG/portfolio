package Lab10;

public enum Operator {

	Operator_NULL, Operator_ADD, Operator_SUB, Operator_MUL, Operator_DIV, Operator_MOD;
	
}
