package Lab10;

public class Calculator {

	float temp1;
	float temp2;
	private float Result = 0;
	private float Inputnum = 0;
	private boolean isFirst;
	public boolean isFirst() {
		return isFirst;
	}

	public void setFirst(boolean isFirst) {
		this.isFirst = isFirst;
	}

	private Operator operator;

	public Operator getOperator() {
		return operator;
	}

	public void setOperator(Operator operator) {
		this.operator = operator;
	}


	public float getResult() {
		return Result;
	}

	public void setResult(float result) {
		this.Result = result;
	}

	public float getInputnum() {
		return Inputnum;
	}

	public Calculator() {

	}

	public void setInputnum(float inputnum) {
		Inputnum = inputnum;
	}

	void Calculation() {
		switch (operator.ordinal()) {
			case 0:
				//null
				break;
			case 1:
				setResult(temp1+temp2);
				//add
				break;
			case 2:
				setResult(temp1-temp2);
				//sub
				break;
			case 3:
				setResult(temp1*temp2);
				//mul
				break;
			case 4:
				setResult(temp1/temp2);
				//div
				break;
			case 5:
				setResult(temp1%temp2);
				//mod
				break;
			

		}
		isFirst =true;
	}

}
