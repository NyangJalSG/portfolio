package Lab10;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class MainFrame extends JFrame implements ActionListener {

	Calculator cal = new Calculator();
	Calculator cal1 = new Calculator();
	Calculator cal2 = new Calculator();
	JLabel labelResult = new JLabel("");
	
	String inputStr = "";
	// JTextField textnum = new JTextField("0");

	JButton btnAC = new JButton("AC");
	JButton btnM1 = new JButton("+/-");
	JButton btnRem = new JButton("%");
	JButton btnDi = new JButton("/");
	JButton btnMu = new JButton("X");
	JButton btnSu = new JButton("-");
	JButton btnAd = new JButton("+");
	JButton btnRes = new JButton("=");

	JButton btn012 = new JButton(".");
	JButton btn01 = new JButton("1");
	JButton btn02 = new JButton("2");
	JButton btn03 = new JButton("3");
	JButton btn04 = new JButton("4");
	JButton btn05 = new JButton("5");
	JButton btn06 = new JButton("6");
	JButton btn07 = new JButton("7");
	JButton btn08 = new JButton("8");
	JButton btn09 = new JButton("9");
	JButton btn00 = new JButton("0");

	Panel panel1 = new Panel();
	Panel panel2 = new Panel();
	Panel panel3 = new Panel();
	Panel panel4 = new Panel();
	Panel panel5 = new Panel();
	Panel panel6 = new Panel();
	Panel panel62 = new Panel();

	public MainFrame() {
		this.setTitle("����");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container cP = this.getContentPane();
		cP.setLayout(new GridLayout(6, 1));
		panel1.setLayout(new GridLayout(1, 1));
		labelResult.setHorizontalAlignment(JTextField.RIGHT);
		panel1.add(labelResult);

		panel2.setLayout(new GridLayout(1, 4));
		panel2.add(btnAC);
		panel2.add(btnM1);
		panel2.add(btnRem);
		panel2.add(btnDi);
		panel3.setLayout(new GridLayout(1, 4));
		panel3.add(btn07);
		panel3.add(btn08);
		panel3.add(btn09);
		panel3.add(btnMu);
		panel4.setLayout(new GridLayout(1, 4));
		panel4.add(btn04);
		panel4.add(btn05);
		panel4.add(btn06);
		panel4.add(btnSu);
		panel5.setLayout(new GridLayout(1, 4));
		panel5.add(btn01);
		panel5.add(btn02);
		panel5.add(btn03);
		panel5.add(btnAd);

		panel6.setLayout(new GridLayout(1, 2));
		panel6.add(btn00);

		panel62.setLayout(new GridLayout(1, 2));
		panel62.add(btn012);
		panel62.add(btnRes);

		panel6.add(panel62);

		this.add(panel1);
		this.add(panel2);
		this.add(panel3);
		this.add(panel4);
		this.add(panel5);
		this.add(panel6);

		setActionListenser();

		this.setSize(300, 200);
		this.setVisible(true);

	}

	private void setActionListenser() {
		// TODO Auto-generated method stub

		btnAC.addActionListener(this);
		btnM1.addActionListener(this);
		btnRem.addActionListener(this);
		btnDi.addActionListener(this);
		btnMu.addActionListener(this);
		btnSu.addActionListener(this);
		btnAd.addActionListener(this);
		btnRes.addActionListener(this);
		btn012.addActionListener(this);
		btn01.addActionListener(this);
		btn02.addActionListener(this);
		btn03.addActionListener(this);
		btn04.addActionListener(this);
		btn05.addActionListener(this);
		btn06.addActionListener(this);
		btn07.addActionListener(this);
		btn08.addActionListener(this);
		btn09.addActionListener(this);
		btn00.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		Object obj = e.getSource();

		if (obj == btn01) {

			labelResult.setText(inputStr += "1");
		} else if (obj == btn02) {
			inputStr += "2";
			labelResult.setText(inputStr);
		} else if (obj == btn03) {
			inputStr += "3";
			labelResult.setText(inputStr);
		} else if (obj == btn04) {
			inputStr += "4";
			labelResult.setText(inputStr);
		}

		else if (obj == btn05) {
			inputStr += "5";
			labelResult.setText(inputStr);
		}

		else if (obj == btn06) {
			inputStr += "6";
			labelResult.setText(inputStr);
		}

		else if (obj == btn07) {
			inputStr += "7";
			labelResult.setText(inputStr);
		}

		else if (obj == btn08) {
			inputStr += "8";
			labelResult.setText(inputStr);
		}

		else if (obj == btn09) {
			inputStr += "9";
			labelResult.setText(inputStr);
		}

		else if (obj == btn00) {
			inputStr += "0";
			labelResult.setText(inputStr);
		}

		else if (obj == btnAC) {
			labelResult.setText("0");
			inputStr = "";
		}

		else if (obj == btnM1) { //-1

			if (!(labelResult.getText().equals(""))&& !(labelResult.getText().equals("."))){
				if (!(labelResult.getText().substring(0).equals("-"))) {
					inputStr = "-" + inputStr;
					labelResult.setText(inputStr);
				} 
				else if ((labelResult.getText().substring(0).equals("-"))); {
				
					labelResult.setText(inputStr.substring(1, inputStr.length()));
				}
			}
			
		}

		else if (obj == btnRem) {
//			addInputNum(labelResult.getText());
//			labelResult.setText("");
//			inputStr="";
			cal.setOperator(Operator.Operator_MOD);
			// ������
			if (!(labelResult.getText().equals(""))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("."))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("+"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("-"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("*"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("/"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("%"))) {

				inputStr += "%";
				labelResult.setText(inputStr);
			}
		}

		else if (obj == btnDi) {
			addInputNum(labelResult.getText());
			labelResult.setText("");
			inputStr="";
			cal.setOperator(Operator.Operator_DIV);
			

			if (!(labelResult.getText().equals(""))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("."))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("+"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("-"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("*"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("/"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("%"))) {

				inputStr += "/";
				labelResult.setText(inputStr);
			}
		}

		else if (obj == btnMu) {
//			addInputNum(labelResult.getText());
//			labelResult.setText("");
//			inputStr="";
			cal.setOperator(Operator.Operator_MUL);

			if (!(labelResult.getText().equals(""))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("."))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("+"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("-"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("*"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("/"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("%"))) {

				inputStr += "*";
				labelResult.setText(inputStr);
			}
		}

		else if (obj == btnSu) {
//			addInputNum(labelResult.getText());
//			labelResult.setText("");
//			inputStr="";
			cal.setOperator(Operator.Operator_SUB);

			if (!(labelResult.getText().equals(""))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("."))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("+"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("-"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("*"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("/"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("%"))) {

				inputStr += "-";
				labelResult.setText(inputStr);
			}
		}

		else if (obj == btnAd) {
//			addInputNum(labelResult.getText());
//			labelResult.setText("");
			cal.setOperator(Operator.Operator_ADD);
//
			if (!(labelResult.getText().equals(""))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("."))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("+"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("-"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("*"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("/"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("%"))) {

				inputStr += "+";
				labelResult.setText(inputStr);
			}
		}

		else if (obj == btn012) {
			if (labelResult.getText().contains("."))
				;
			else if (!(labelResult.getText().equals(""))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("+"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("-"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("*"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("/"))
					&& !(labelResult.getText().substring(labelResult.getText().length() - 1).equals("%"))) {
				inputStr += ".";
				labelResult.setText(inputStr);
			}

		}

		else if (obj == btnRes) {
			
			runCalculator();
		}

	}

	void runCalculator() {
		if (labelResult.getText().equals(""))
			return;
			
		cal.Calculation();
		
		
	}

	void setlabelResult() {
//		cal.setInputnum(cal.getResult());
		viewLabelResult();
	}

	void viewLabelResult() {
		labelResult.setText(num2Str(cal.getResult()));
	}

	void addInputNum(String num) {
		cal.setInputnum(Float.parseFloat(num));

	}
	//����� Stringȭ
	String num2Str(float num) {
		return String.valueOf(num);
	}

}
