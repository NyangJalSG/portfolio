package Lab07;

public interface Animals {
	void Death();
	  
	void Eat();
	  
	void Run();
	
}
