
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab06 runs =new Lab06();
		runs.run();
	
	}

}
