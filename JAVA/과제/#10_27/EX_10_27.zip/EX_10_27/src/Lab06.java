import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab06 {
	
	int select;
	Scanner s = new Scanner(System.in);	
	boolean flag=false;
	Word[] words = new Word[1000];
	int size =0;
	StringBuffer sb = new StringBuffer("");
	StringBuffer nsb = new StringBuffer(""); //���ο� ����� ���ڿ�
	int j=0;
	void run() {	
		while (flag==false)
		{
		System.out.println("���ϴ� �޴��� �����ϼ���");
		System.out.println("1. ó�� ���� ����");
		System.out.println("2. ó�� ��� ����");
		System.out.println("3. ó�� ��� ȭ�鿡 ���");
		System.out.println("4. ����");
		select = s.nextInt();
		switch(Menu.int2Menu(select)) {
		case Open_file:
			{	
			open();
			break;
			}
		case Save_file:
			{
			save();
			break;
			}
		
		case Print_file:
			{
			print();
			break;		
			}
		case Quit:
			return;
		case None:
			break;
		}
		}
	}
	
	void open() {
		int ch;
		try {
			FileInputStream fis = new FileInputStream("./src/my_byte_file_in/test5.txt"); 
			while ((ch=fis.read())!=-1){
				if((char)ch=='#') {
					for (j=0 ; j<size ; j++) {
						if(words[j].compare(sb.toString())) {
							words[j].num++;
							sb.delete(0,sb.toString().length()+1);
							break;
						}
					}
					if(j>=size) {
						words[size]=new Word(sb.toString());				
						size++;
						sb.delete(0,sb.toString().length()+1);
					}
				}
				else {
					sb.append((char)ch);
				}			
			}
			fis.close();
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}	
	}
	void save() {
		try {
			FileWriter fwriter = new FileWriter("./src/my_string_file_in/test6.txt");
			BufferedWriter bwriter = new BufferedWriter(fwriter);			
			for (int k=0 ; k<size;k++)
			{
			fwriter.write(words[k].s.toString()+"%");
			}
			fwriter.close();
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	void print() {
		int ch;
		try {
			FileInputStream fis = new FileInputStream("./src/my_string_file_in/test6.txt"); 
			while ((ch=fis.read())!=-1){
				nsb.append((char)ch);				
			}
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}	
		int i=0;
		StringTokenizer st = new StringTokenizer(nsb.toString(),"%");
		while(st.hasMoreTokens()){
			System.out.println(st.nextToken());	
			System.out.println(words[i].num + "��");
			i++;
		}
	}
	
	
}

