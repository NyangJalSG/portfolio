
public enum Menu {
	
	Open_file, Save_file, Print_file, Quit,None;
	
	static public Menu int2Menu(int i) {
		switch(i) {
		case 1:
			return Open_file;
		case 2:
			return Save_file;
		case 3:
			return Print_file;
		case 4:
			return Quit;
		
		}
		return Menu.None;
	}

	
}
