package Lab08;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLStreamException;

import org.xml.sax.SAXException;

public class MainClass {

	public static void main(String[] args) throws FileNotFoundException, ParserConfigurationException, SAXException, IOException, XMLStreamException, FactoryConfigurationError {
		// TODO Auto-generated method stub
		Application app = new Application();
		app.run();
	}
}
