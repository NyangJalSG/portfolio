package Lab08;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class Application {

	public void run() throws ParserConfigurationException, SAXException,
			FileNotFoundException, IOException, XMLStreamException,
			FactoryConfigurationError {
		// TODO Auto-generated method stub

		// SAX 객체 생성 메서드
		SAXParserFactory saxPF = SAXParserFactory.newInstance();
		// SAX 파서 객체 생성
		SAXParser saxP = saxPF.newSAXParser();
		// SAX XML 리더 객체 생성
		XMLReader xmlR = saxP.getXMLReader();
		// XML 파일 객체 생성
		File file = new File("./src/Lab08/save.xml");
		// XML 파싱 규칙 핸들러
		// Xml_Handler dhandler = new Xml_Handler();
		// XML 핸들러 지정
		// xmlR.setContentHandler(dhandler);
		// XML 파일 파싱 요청
		// xmlR.parse(new InputSource(new FileInputStream(file)));

		HashMap<String, LinkedList> hm = new HashMap<String, LinkedList>();
		LinkedList<Dog> doglist = new LinkedList<Dog>();
		LinkedList<Chicken> chickenlist = new LinkedList<Chicken>();
		LinkedList<Cat> catlist = new LinkedList<Cat>();
		LinkedList<Iguana> iguanalist = new LinkedList<Iguana>();
		LinkedList<Parrot> parrotlist = new LinkedList<Parrot>();
		LinkedList<Chameleon> chameleonlist = new LinkedList<Chameleon>();
		hm.put("개", doglist);
		hm.put("고양이", catlist);
		hm.put("앵무새", parrotlist);
		hm.put("닭", chickenlist);
		hm.put("이구아나", iguanalist);
		hm.put("카멜레온", chameleonlist);

		Scanner s = new Scanner(System.in);
		int year = 0;
		int random;
		int num = 0;
		int menu;
		boolean flag = false;
		while (flag == false) {
			System.out.println("메뉴를 선택하세요");
			System.out.println("1. 다음 연도로 진행");
			System.out.println("2. 동물의 개수 출력");
			System.out.println("3. 모든 동물의 먹기 호출");
			System.out.println("4. 모든 동물의 뛰기 호출");
			System.out.println("5. 모든 동물의 정보 출력");
			System.out.println("6. 특정 동물의 먹기 호출");
			System.out.println("7. 특정 동물의 뛰기 호출");
			System.out.println("8. 특정 동물의 정보 출력");
			System.out.println("9. 파일 저장");
			System.out.println("10.파일 불러오기");
			System.out.println("0. : 끝내기");
			menu = s.nextInt();
			if (menu == 1) {
				year++;
				System.out.println(year + "년째입니다");
				random = (int) (Math.random() * 6 + 1);
				if (random == 1) {
					doglist.add(new Dog());
					doglist.get(doglist.size() - 1).birth = year;
					num++;
					System.out.println("개 탄생");
				} else if (random == 2) {
					catlist.add(new Cat());
					catlist.get(catlist.size() - 1).birth = year;
					num++;
					System.out.println("고양이 탄생");
				} else if (random == 3) {
					parrotlist.add(new Parrot());
					parrotlist.get(parrotlist.size() - 1).birth = year;
					num++;
					System.out.println("앵무새 탄생");
				} else if (random == 4) {
					chickenlist.add(new Chicken());
					chickenlist.get(chickenlist.size() - 1).birth = year;
					num++;
					System.out.println("닭 탄생");
				} else if (random == 5) {
					iguanalist.add(new Iguana());
					iguanalist.get(iguanalist.size() - 1).birth = year;
					num++;
					System.out.println("이구아나 탄생");
				} else if (random == 6) {
					chameleonlist.add(new Chameleon());
					chameleonlist.get(chameleonlist.size() - 1).birth = year;
					num++;
					System.out.println("카멜레온 탄생");
				}
				// 사망처리
				for (int i = 0; i < doglist.size(); i++) {
					if (doglist.get(i).life - (year - doglist.get(i).birth) <= 0) {
						doglist.get(i).Death();
						doglist.remove(i); // 아예 리스트에서 제거 죽은 동물들이 안뜸
						System.out.println("개 사망");
					}
				}
				for (int i = 0; i < catlist.size(); i++) {
					if (catlist.get(i).life - (year - catlist.get(i).birth) <= 0) {
						catlist.get(i).Death();
						catlist.remove(i); // 아예 리스트에서 제거 죽은 동물들이 안뜸
						System.out.println("고양이 사망");
					}
				}
				for (int i = 0; i < parrotlist.size(); i++) {
					if (parrotlist.get(i).life
							- (year - parrotlist.get(i).birth) <= 0) {
						parrotlist.get(i).Death();
						parrotlist.remove(i); // 아예 리스트에서 제거 죽은 동물들이 안뜸
						System.out.println("앵무새 사망");
					}
				}
				for (int i = 0; i < chickenlist.size(); i++) {
					if (chickenlist.get(i).life
							- (year - chickenlist.get(i).birth) <= 0) {
						chickenlist.get(i).Death();
						chickenlist.remove(i); // 아예 리스트에서 제거 죽은 동물들이 안뜸
						System.out.println("닭 사망");
					}
				}
				for (int i = 0; i < iguanalist.size(); i++) {
					if (iguanalist.get(i).life
							- (year - iguanalist.get(i).birth) <= 0) {
						iguanalist.get(i).Death();
						iguanalist.remove(i); // 아예 리스트에서 제거 죽은 동물들이 안뜸
						System.out.println("이구아나 사망");
					}
				}
				for (int i = 0; i < chameleonlist.size(); i++) {
					if (chameleonlist.get(i).life
							- (year - chameleonlist.get(i).birth) <= 0) {
						chameleonlist.get(i).Death();
						chameleonlist.remove(i); // 아예 리스트에서 제거 죽은 동물들이 안뜸
						System.out.println("카멜레온 사망");
					}
				}

			} else if (menu == 2) {
				System.out.println("총 " + Animal.num + "마리");
				System.out.println("포유류 " + Mammal.num + "마리");
				System.out.println("조류 " + Bird.num + "마리");
				System.out.println("파충류 " + Reptile.num + "마리");
				System.out.println("개 " + Dog.num + "마리");
				System.out.println("고양이 " + Cat.num + "마리");
				System.out.println("앵무새 " + Parrot.num + "마리");
				System.out.println("닭 " + Chicken.num + "마리");
				System.out.println("이구아나 " + Iguana.num + "마리");
				System.out.println("카멜레온 " + Chameleon.num + "마리");
			} else if (menu == 3) {
				Iterator<String> keys = hm.keySet().iterator();
				while (keys.hasNext()) {
					String key = keys.next();
					if (key == "개") {
						for (int i = 0; i < doglist.size(); i++) {
							doglist.get(i).Eat();
						}
					} else if (key == "고양이") {
						for (int i = 0; i < catlist.size(); i++) {
							catlist.get(i).Eat();
						}
					} else if (key == "앵무새") {
						for (int i = 0; i < parrotlist.size(); i++) {
							parrotlist.get(i).Eat();
						}
					} else if (key == "닭") {
						for (int i = 0; i < chickenlist.size(); i++) {
							chickenlist.get(i).Eat();
						}
					} else if (key == "이구아나") {
						for (int i = 0; i < iguanalist.size(); i++) {
							iguanalist.get(i).Eat();
						}
					} else if (key == "카멜레온") {
						for (int i = 0; i < chameleonlist.size(); i++) {
							chameleonlist.get(i).Eat();
						}
					}
				}
			} else if (menu == 4) {
				Iterator<String> keys = hm.keySet().iterator();
				while (keys.hasNext()) {
					String key = keys.next();
					if (key == "개") {
						for (int i = 0; i < doglist.size(); i++) {
							doglist.get(i).Run();
						}
					} else if (key == "고양이") {
						for (int i = 0; i < catlist.size(); i++) {
							catlist.get(i).Run();
						}
					} else if (key == "앵무새") {
						for (int i = 0; i < parrotlist.size(); i++) {
							parrotlist.get(i).Run();
						}
					} else if (key == "닭") {
						for (int i = 0; i < chickenlist.size(); i++) {
							chickenlist.get(i).Run();
						}
					} else if (key == "이구아나") {
						for (int i = 0; i < iguanalist.size(); i++) {
							iguanalist.get(i).Run();
						}
					} else if (key == "카멜레온") {
						for (int i = 0; i < chameleonlist.size(); i++) {
							chameleonlist.get(i).Run();
						}
					}
				}

			} else if (menu == 5) {
				Iterator<String> keys = hm.keySet().iterator();
				while (keys.hasNext()) {
					String key = keys.next();
					if (key == "개") {
						for (int i = 0; i < doglist.size(); i++) {
							doglist.get(i).PrintInfo(year);
						}
					} else if (key == "고양이") {
						for (int i = 0; i < catlist.size(); i++) {
							catlist.get(i).PrintInfo(year);
						}
					} else if (key == "앵무새") {
						for (int i = 0; i < parrotlist.size(); i++) {
							parrotlist.get(i).PrintInfo(year);
						}
					} else if (key == "닭") {
						for (int i = 0; i < chickenlist.size(); i++) {
							chickenlist.get(i).PrintInfo(year);
						}
					} else if (key == "이구아나") {
						for (int i = 0; i < iguanalist.size(); i++) {
							iguanalist.get(i).PrintInfo(year);
						}
					} else if (key == "카멜레온") {
						for (int i = 0; i < chameleonlist.size(); i++) {
							chameleonlist.get(i).PrintInfo(year);
						}
					}
				}

			} else if (menu == 6) {
				System.out.println("어떤 동물을 먹기를 출력");
				String what = s.next();
				if (what.equals("개")) {
					for (int i = 0; i < doglist.size(); i++) {
						doglist.get(i).Eat();
					}
				} else if (what.equals("고양이")) {
					for (int i = 0; i < catlist.size(); i++) {
						catlist.get(i).Eat();
						;
					}
				} else if (what.equals("앵무새")) {
					for (int i = 0; i < parrotlist.size(); i++) {
						parrotlist.get(i).Eat();
					}
				} else if (what.equals("닭")) {
					for (int i = 0; i < chickenlist.size(); i++) {
						chickenlist.get(i).Eat();
						;
					}
				} else if (what.equals("이구아나")) {
					for (int i = 0; i < iguanalist.size(); i++) {
						iguanalist.get(i).Eat();
					}
				} else if (what.equals("카멜레온")) {
					for (int i = 0; i < chameleonlist.size(); i++) {
						chameleonlist.get(i).Eat();
					}
				} else {
					System.out.println("없는 동물입니다");
				}
			} else if (menu == 7) {
				System.out.println("어떤 동물을 뛰기를 출력");
				String what = s.next();
				if (what.equals("개")) {
					for (int i = 0; i < doglist.size(); i++) {
						doglist.get(i).Run();
					}
				} else if (what.equals("고양이")) {
					for (int i = 0; i < catlist.size(); i++) {
						catlist.get(i).Run();
					}
				} else if (what.equals("앵무새")) {
					for (int i = 0; i < parrotlist.size(); i++) {
						parrotlist.get(i).Run();
					}
				} else if (what.equals("닭")) {
					for (int i = 0; i < chickenlist.size(); i++) {
						chickenlist.get(i).Run();
					}
				} else if (what.equals("이구아나")) {
					for (int i = 0; i < iguanalist.size(); i++) {
						iguanalist.get(i).Run();
					}
				} else if (what.equals("카멜레온")) {
					for (int i = 0; i < chameleonlist.size(); i++) {
						chameleonlist.get(i).Run();
					}
				} else {
					System.out.println("없는 동물입니다");
				}

			} else if (menu == 8) {
				System.out.println("어떤 동물을 정보출력");
				String what = s.next();
				if (what.equals("개")) {
					for (int i = 0; i < doglist.size(); i++) {
						doglist.get(i).PrintInfo(year);
					}
				} else if (what.equals("고양이")) {
					for (int i = 0; i < catlist.size(); i++) {
						catlist.get(i).PrintInfo(year);
					}
				} else if (what.equals("앵무새")) {
					for (int i = 0; i < parrotlist.size(); i++) {
						parrotlist.get(i).PrintInfo(year);
					}
				} else if (what.equals("닭")) {
					for (int i = 0; i < chickenlist.size(); i++) {
						chickenlist.get(i).PrintInfo(year);
					}
				} else if (what.equals("이구아나")) {
					for (int i = 0; i < iguanalist.size(); i++) {
						iguanalist.get(i).PrintInfo(year);
					}
				} else if (what.equals("카멜레온")) {
					for (int i = 0; i < chameleonlist.size(); i++) {
						chameleonlist.get(i).PrintInfo(year);
					}
				} else {
					System.out.println("없는 동물입니다");
				}
			} else if (menu == 9) {
				OutputStream outputStream = new FileOutputStream(file);

				OutputStreamWriter ops = new OutputStreamWriter(outputStream);

				XMLOutputFactory factory = XMLOutputFactory.newInstance();

				XMLStreamWriter xmlW = factory.createXMLStreamWriter(ops);

				xmlW.writeStartDocument("UTF-8", "1.0");

				xmlW.writeStartElement("동물리스트");
				Iterator<String> keys = hm.keySet().iterator();

				while (keys.hasNext()) {
					String key = keys.next();
					if (key == "개") {
						for (int i = 0; i < doglist.size(); i++) {
							xmlW.writeStartElement("동물");
							xmlW.writeAttribute("강이름", "포유류");
							xmlW.writeAttribute("종이름", "개");

							xmlW.writeStartElement("태어난해");
							xmlW.writeCharacters(String.valueOf(doglist.get(i).birth));
							xmlW.writeEndElement();

							xmlW.writeStartElement("수명");
							xmlW.writeCharacters(String.valueOf(doglist.get(i).life));
							xmlW.writeEndElement();

							xmlW.writeStartElement("다리개수");
							xmlW.writeCharacters(String.valueOf(doglist.get(i).feet));
							xmlW.writeEndElement();

							xmlW.writeStartElement("이빨수");
							xmlW.writeCharacters(String.valueOf(doglist.get(i).teeth));
							xmlW.writeEndElement();

							xmlW.writeEndElement();
						}
					} else if (key == "고양이") {
						for (int i = 0; i < catlist.size(); i++) {
							xmlW.writeStartElement("동물");
							xmlW.writeAttribute("강이름", "포유류");
							xmlW.writeAttribute("종이름", "고양이");

							xmlW.writeStartElement("태어난해");
							xmlW.writeCharacters(String.valueOf(catlist.get(i).birth));
							xmlW.writeEndElement();

							xmlW.writeStartElement("수명");
							xmlW.writeCharacters(String.valueOf(catlist.get(i).life));
							xmlW.writeEndElement();

							xmlW.writeStartElement("다리개수");
							xmlW.writeCharacters(String.valueOf(catlist.get(i).feet));
							xmlW.writeEndElement();

							xmlW.writeStartElement("이빨수");
							xmlW.writeCharacters(String.valueOf(catlist.get(i).teeth));
							xmlW.writeEndElement();

							xmlW.writeEndElement();
						}

					} else if (key == "앵무새") {
						for (int i = 0; i < parrotlist.size(); i++) {
							xmlW.writeStartElement("동물");
							xmlW.writeAttribute("강이름", "조류");
							xmlW.writeAttribute("종이름", "앵무새");

							xmlW.writeStartElement("태어난해");
							xmlW.writeCharacters(String.valueOf(parrotlist
									.get(i).birth));
							xmlW.writeEndElement();

							xmlW.writeStartElement("수명");
							xmlW.writeCharacters(String.valueOf(parrotlist
									.get(i).life));
							xmlW.writeEndElement();

							xmlW.writeStartElement("다리개수");
							xmlW.writeCharacters(String.valueOf(parrotlist
									.get(i).feet));
							xmlW.writeEndElement();

							xmlW.writeStartElement("날개수");
							xmlW.writeCharacters(String.valueOf(parrotlist
									.get(i).wing));
							xmlW.writeEndElement();

							xmlW.writeEndElement();
						}

					} else if (key == "닭") {
						for (int i = 0; i < chickenlist.size(); i++) {
							xmlW.writeStartElement("동물");
							xmlW.writeAttribute("강이름", "조류");
							xmlW.writeAttribute("종이름", "닭");

							xmlW.writeStartElement("태어난해");
							xmlW.writeCharacters(String.valueOf(chickenlist
									.get(i).birth));
							xmlW.writeEndElement();

							xmlW.writeStartElement("수명");
							xmlW.writeCharacters(String.valueOf(chickenlist
									.get(i).life));
							xmlW.writeEndElement();

							xmlW.writeStartElement("다리개수");
							xmlW.writeCharacters(String.valueOf(chickenlist
									.get(i).feet));
							xmlW.writeEndElement();

							xmlW.writeStartElement("날개수");
							xmlW.writeCharacters(String.valueOf(chickenlist
									.get(i).wing));
							xmlW.writeEndElement();

							xmlW.writeEndElement();
						}

					} else if (key == "이구아나") {
						for (int i = 0; i < iguanalist.size(); i++) {
							xmlW.writeStartElement("동물");
							xmlW.writeAttribute("강이름", "파충류");
							xmlW.writeAttribute("종이름", "이구아나");

							xmlW.writeStartElement("태어난해");
							xmlW.writeCharacters(String.valueOf(iguanalist
									.get(i).birth));
							xmlW.writeEndElement();

							xmlW.writeStartElement("수명");
							xmlW.writeCharacters(String.valueOf(iguanalist
									.get(i).life));
							xmlW.writeEndElement();

							xmlW.writeStartElement("다리개수");
							xmlW.writeCharacters(String.valueOf(iguanalist
									.get(i).feet));
							xmlW.writeEndElement();

							xmlW.writeEndElement();
						}

					} else if (key == "카멜레온") {
						for (int i = 0; i < chameleonlist.size(); i++) {
							xmlW.writeStartElement("동물");
							xmlW.writeAttribute("강이름", "파충류");
							xmlW.writeAttribute("종이름", "카멜레온");

							xmlW.writeStartElement("태어난해");
							xmlW.writeCharacters(String.valueOf(chameleonlist
									.get(i).birth));
							xmlW.writeEndElement();

							xmlW.writeStartElement("수명");
							xmlW.writeCharacters(String.valueOf(chameleonlist
									.get(i).life));
							xmlW.writeEndElement();

							xmlW.writeStartElement("다리개수");
							xmlW.writeCharacters(String.valueOf(chameleonlist
									.get(i).feet));
							xmlW.writeEndElement();

							xmlW.writeEndElement();
						}

					}

				}
				xmlW.writeEndElement();
				xmlW.close();

			} else if (menu == 10) {
				// 일단 몰살
				
				int dogsize = doglist.size();
				int catsize = catlist.size();
				int parrotsize = parrotlist.size();
				int chickensize = chickenlist.size();
				int iguanasize = iguanalist.size();
				int chameleonsize = chameleonlist.size();
				for (int i = 0; i < doglist.size(); i++) {
					doglist.get(i).Death();
				}
				doglist.clear();
				
				for (int i = 0; i < catlist.size(); i++) {
					catlist.get(i).Death();
				}
				catlist.clear();
				for (int i = 0; i < parrotlist.size(); i++) {
					parrotlist.get(i).Death();					
				}
				parrotlist.clear();
				for (int i = 0; i < chickenlist.size(); i++) {
					chickenlist.get(i).Death();
				}
				chickenlist.clear();
				for (int i = 0; i < iguanalist.size(); i++) {
					iguanalist.get(i).Death();
				}
				iguanalist.clear();
				for (int i = 0; i < chameleonlist.size(); i++) {
					chameleonlist.get(i).Death();
				}
				chameleonlist.clear();
				
				year = 0;

				
				String url = "./src/Lab08/save.xml";
				DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
				DocumentBuilder parser = f.newDocumentBuilder();

				Document xmlDoc = null;
				xmlDoc = parser.parse(url);

				Element root = xmlDoc.getDocumentElement();
			//	System.out.println(root.getTagName());

				NodeList n1 = root.getElementsByTagName("동물");
				for (int i = 0; i < n1.getLength(); i++) {
					Node AnimalNode = n1.item(i);
					Element AnimalElement = (Element) AnimalNode;

					String kangname = AnimalElement.getAttribute("강이름");
				//	System.out.println(kangname);

					String zongname = AnimalElement.getAttribute("종이름");
				//	System.out.println(zongname);

					String birthday = AnimalElement
							.getElementsByTagName("태어난해").item(0)
							.getTextContent();
				//	System.out.println(birthday);

					String lifeday = AnimalElement.getElementsByTagName("수명")
							.item(0).getTextContent();
				//	System.out.println(lifeday);

					String feetnum = AnimalElement.getElementsByTagName("다리개수")
							.item(0).getTextContent();
				//	System.out.println(lifeday);

					if (kangname == "포유류") {
						String teethnum = AnimalElement
								.getElementsByTagName("이빨수").item(0)
								.getTextContent();
					//	System.out.println(teethnum);
						
					} else if (kangname == "조류") {
						String wingnum = AnimalElement
								.getElementsByTagName("날개수").item(0)
								.getTextContent();
					//	System.out.println(wingnum);
					} else;
					
					if (zongname.equals("개")){
						doglist.add(new Dog());
						doglist.get(doglist.size() - 1).birth = Integer.parseInt(birthday);
					}
					else if (zongname.equals("고양이")){
						catlist.add(new Cat());
						catlist.get(catlist.size() - 1).birth = Integer.parseInt(birthday);
					}

					else if (zongname.equals("앵무새")){
						parrotlist.add(new Parrot());
						parrotlist.get(parrotlist.size() - 1).birth = Integer.parseInt(birthday);
					}

					else if (zongname.equals("닭")){
						chickenlist.add(new Chicken());
						chickenlist.get(chickenlist.size() - 1).birth = Integer.parseInt(birthday);
					}

					else if (zongname.equals("이구아나")){
						iguanalist.add(new Iguana());
						iguanalist.get(iguanalist.size() - 1).birth = Integer.parseInt(birthday);
					}

					else if (zongname.equals("카멜레온")){
						chameleonlist.add(new Chameleon());
						chameleonlist.get(chameleonlist.size() - 1).birth = Integer.parseInt(birthday);
					}

					
				}
			} else if (menu == 0)
				return;
			else
				;
		}
	}
}
