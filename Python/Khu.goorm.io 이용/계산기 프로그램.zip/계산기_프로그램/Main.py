num1=int(input())
num2=int(input())
op=input()
if op == '+':
	result = num1+num2
elif op == '-' :
	result = num1-num2
elif op == '*' :
	result = num1*num2
elif op == '/' :
	result = num1/num2 
print(result)
	