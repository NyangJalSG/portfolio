# -*- coding: utf-8 -*-
# UTF-8 encoding when using korean
radius = input()
circle = int(radius)*3.141592
print (radius + " * 3.141592 = " + str("%0.3f" %circle))
