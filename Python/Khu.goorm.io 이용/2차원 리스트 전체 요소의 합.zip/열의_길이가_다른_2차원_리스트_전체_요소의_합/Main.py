list2=[[1,2,3,10],[6,8,12],[23,4],[11,2,36]]
sum=0
for i in list2:
	for j in i:
		sum+=j
print(sum)