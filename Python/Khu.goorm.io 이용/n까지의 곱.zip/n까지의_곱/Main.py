n=int(input())
num=1
mul=1
while(num<=n):
	mul=num*mul
	num+=1
print(mul)