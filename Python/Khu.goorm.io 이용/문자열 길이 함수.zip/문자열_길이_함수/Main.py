str1=input()
str2=input()
print(len(str1)+len(str2))