clock = int(input())
minute = int(input())
where = input()
print("오늘 회의는 %d시 %d분에, \"%s\"에서 진행됩니다." %(clock,minute,where))
