str = "Python is very fun!"
print(str)