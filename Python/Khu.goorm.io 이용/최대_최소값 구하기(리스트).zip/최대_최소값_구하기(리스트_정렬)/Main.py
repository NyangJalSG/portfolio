list1=[]
minnum=0
maxnum=0
for i in range(0, 3):
	list1.append(int(input()))

minnum=min(list1)
maxnum=max(list1)
print(minnum)
print(maxnum)
