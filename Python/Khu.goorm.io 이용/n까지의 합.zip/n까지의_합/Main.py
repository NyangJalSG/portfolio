n=int(input())
num=1
sum=0
while(num<=n):
	sum+=num
	num+=1
print(sum)

	