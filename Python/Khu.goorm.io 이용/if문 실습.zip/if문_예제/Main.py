money=int(input())
if money >=5000:
	print("커피를 마신다.")
else :
	print("물을 마신다.")