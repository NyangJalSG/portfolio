str = "Kyung" + "\n" + "Hee" + "\n" + "University"
print(str)