str1 = "Shout out"
str2 = ' "Once more!"'
str = str1+ str2
print(str)