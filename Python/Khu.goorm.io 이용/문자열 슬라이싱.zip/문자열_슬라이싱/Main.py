str = "Python is very fun!"
sub_str=str[10:14]
print(sub_str)