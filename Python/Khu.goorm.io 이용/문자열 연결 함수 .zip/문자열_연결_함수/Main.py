str1=input()
str2=input()
l = [str1,str2]
print(" ".join(l))