print('{0:<8} {1:>8}'.format("Product","Price"))
print('{0:<8} {1:>8}'.format("TV","3000"))
print('{0:<8} {1:>8}'.format("Table","500"))
print('{0:<8} {1:>8}'.format("Pen","30"))